// Coupon Sheet — apply a coupon code to the order.
//
// Emits coupon:apply (or discount:apply with coupon_code) to Desktop.
// Currently the Desktop operator gateway does not have a dedicated
// coupon:apply event, so we use discount:apply with a coupon_code field.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/providers.dart';
import '../theme/tokens.dart';
import 'liquid_chrome.dart';
import 'liquid_glass_surface.dart';

class CouponSheet extends ConsumerStatefulWidget {
  final String orderId;
  const CouponSheet({super.key, required this.orderId});

  static Future<Map<String, dynamic>?> show(
    BuildContext context, {
    required String orderId,
  }) {
    return showModalBottomSheet<Map<String, dynamic>>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withValues(alpha: 0.32),
      builder: (_) => CouponSheet(orderId: orderId),
    );
  }

  @override
  ConsumerState<CouponSheet> createState() => _CouponSheetState();
}

class _CouponSheetState extends ConsumerState<CouponSheet> {
  final TextEditingController _code = TextEditingController();
  bool _applying = false;
  String? _error;
  String? _success;

  @override
  void dispose() {
    _code.dispose();
    super.dispose();
  }

  void _apply() {
    final code = _code.text.trim();
    if (code.isEmpty) {
      setState(() => _error = 'Enter a coupon code');
      return;
    }
    setState(() {
      _applying = true;
      _error = null;
    });

    final socketService = ref.read(socketServiceProvider);
    socketService.emit('discount:apply', <String, dynamic>{
      'order_id': widget.orderId,
      'coupon_code': code,
    }, onAck: (response) {
      if (!mounted) return;
      if (response['kind'] == 'error') {
        setState(() {
          _applying = false;
          _error = response['message']?.toString() ?? 'Invalid coupon';
        });
      } else {
        setState(() {
          _applying = false;
          _success = 'Coupon applied!';
        });
        Future.delayed(const Duration(milliseconds: 800), () {
          if (mounted) Navigator.of(context).pop(response);
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
      initialChildSize: 0.45,
      maxChildSize: 0.7,
      minChildSize: 0.3,
      expand: false,
      builder: (_, scroll) => LiquidGlassSurface(
        blur: 30,
        thickness: 14,
        borderRadius: const BorderRadius.vertical(top: AppRadii.lg),
        padding: EdgeInsets.zero,
        child: Column(
          children: [
            const SizedBox(height: 8),
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: AppColors.ink30,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Icon(Icons.local_offer_outlined,
                      color: AppColors.terra600, size: 20),
                  SizedBox(width: 8),
                  Text('Apply Coupon', style: AppTypography.title),
                ],
              ),
            ),
            const Divider(height: 1, color: AppColors.ink10),
            Expanded(
              child: ListView(
                controller: scroll,
                padding: const EdgeInsets.all(16),
                children: [
                  LiquidGlassSurface(
                    borderRadius: const BorderRadius.all(AppRadii.sm),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
                    blur: 18,
                    thickness: 8,
                    child: TextField(
                      controller: _code,
                      textCapitalization: TextCapitalization.characters,
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        hintText: 'Enter coupon code',
                        icon: Icon(Icons.confirmation_number_outlined,
                            color: AppColors.ink50),
                      ),
                      onChanged: (_) {
                        if (_error != null) setState(() => _error = null);
                      },
                      onSubmitted: (_) => _apply(),
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 8),
                    Text(_error!,
                        style: AppTypography.caption
                            .copyWith(color: AppColors.danger)),
                  ],
                  if (_success != null) ...[
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        const Icon(Icons.check_circle,
                            color: AppColors.success, size: 16),
                        const SizedBox(width: 6),
                        Text(_success!,
                            style: AppTypography.bodyMd.copyWith(
                                color: AppColors.success,
                                fontWeight: FontWeight.w600)),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(
                  16, 8, 16, 16 + MediaQuery.of(context).viewPadding.bottom),
              child: LiquidPrimaryButton(
                label: _applying ? 'Applying...' : 'Apply Coupon',
                fullWidth: true,
                leadingIcon: _applying ? Icons.hourglass_top : Icons.check,
                onPressed: _applying ? null : _apply,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
